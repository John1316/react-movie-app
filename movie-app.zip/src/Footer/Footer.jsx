import React from 'react'

export default function Footer() {
  return (
    <div className='bg-dark py-3 text-center text-white mt-2'>Footer</div>
  )
}
