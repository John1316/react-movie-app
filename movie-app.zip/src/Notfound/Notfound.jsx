import React from 'react'

export default function Notfound() {
  return (
    <div>Notfound</div>
  )
}
