import React from 'react'

export default function People() {
  return (
    <div>People</div>
  )
}
